// para compilar: mpicc hello.c -o hello -Wall
// para rodar: mpirun -np 2 hello
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mpi.h"
#define MESSAGE "Hello World running!!!! " 
int  main(int argc, char *argv[])  {
	int npes, myrank, src, dest, msgtag, ret;
	char *bufrecv, *bufsend;
	MPI_Status status;
	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &npes);
	MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
	bufrecv = (char *) malloc (strlen(MESSAGE)+12);
   	msgtag = 1;
	if ( myrank == 0) {
        	//printf("There are %d processes.\n", npes);
		//printf("I am process %d. Message with %d char. \n",
		//        myrank, strlen(MESSAGE));
		//src = dest = 1;
		for (dest = 1; dest<npes; dest ++)
		  MPI_Send(MESSAGE, strlen(MESSAGE)+1, MPI_CHAR, dest, msgtag, MPI_COMM_WORLD);
		
		msgtag = 2;
		for (src = 1; src < npes; src++) {
		  MPI_Recv(bufrecv, strlen(MESSAGE)+12, MPI_CHAR, MPI_ANY_SOURCE, msgtag, MPI_COMM_WORLD, &status);
	 	  printf("Received message from slave: %s with %d char \n", 
                        bufrecv, strlen(bufrecv));
		}
	}
	else {
		//printf("There are %d processes. I am process %d \n", npes, myrank);
		bufsend = (char *) malloc (strlen(MESSAGE)+12);
		src = dest = 0;
		MPI_Recv(bufrecv, strlen(MESSAGE)+1, MPI_CHAR, src, msgtag, MPI_COMM_WORLD, &status);
		msgtag = 2;
		sprintf(bufsend, "%s from %d", bufrecv, myrank);
		MPI_Send(bufsend, strlen(bufsend)+1, MPI_CHAR, dest, msgtag, MPI_COMM_WORLD);
		free(bufsend);
	}
	free(bufrecv);
	fflush(0);
	ret = MPI_Finalize();
	if (ret == MPI_SUCCESS)
		printf("MPI_Finalize success! \n");
	return(0);
}
